#ifdef __cplusplus
extern "C"
{
#endif

#ifndef __FONT__
  #define __FONT__

  #include <stdint.h>

  #define SMALLBITMAPX 39
  #define SMALLBITMAPY 5
  extern uint8_t smallbitmap[SMALLBITMAPX][SMALLBITMAPY];

#endif // __FONT__

#ifdef __cplusplus
}
#endif
